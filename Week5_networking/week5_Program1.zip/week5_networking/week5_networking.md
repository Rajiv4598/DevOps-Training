# Week 5 — Networking Basics for DevOps
*Generated: 2025-10-17 14:26:03*

This week you’ll touch the essentials: **IPs, ports, DNS, firewalls**. We’ll verify your IP, test connectivity, fetch web content, and list open ports. We’ll also capture outputs into the `artifacts/` folder for documentation.

> Commands are for Linux (Ubuntu/Debian/Amazon Linux). If a tool is missing, install it with the notes below.

---

## 0) Setup folder
```bash
mkdir -p ~/projects/devops/week5/week5_networking/artifacts
cd ~/projects/devops/week5/week5_networking
pwd
```

---

## 1) Find your IP
Prefer `ip addr` (modern). `ifconfig` requires the **net-tools** package.

```bash
# modern
ip addr show

# legacy (if installed)
ifconfig
```

**Install net-tools if needed:**
```bash
# Ubuntu/Debian
sudo apt update && sudo apt install -y net-tools

# Amazon Linux 2023 / RHEL-family
sudo dnf install -y net-tools
```

Tips:
- Look for an interface like `eth0`, `ens...`, or `wlan0`.
- `inet 192.168.x.y/24` is your IPv4; `inet6` is IPv6.

---

## 2) Test connectivity (DNS + ICMP)
```bash
ping -c 4 google.com
```

If `ping` to hostname fails, try an IP (checks pure connectivity):
```bash
ping -c 4 8.8.8.8
```

---

## 3) Fetch a page with curl
```bash
# headers only
curl -I https://example.com

# first lines of the body
curl -L https://example.com | head -n 20
```

Common flags: `-L` follow redirects, `-s` silent, `-v` verbose.

---

## 4) List open/listening ports
`netstat` comes from **net-tools**. The modern replacement is `ss`.

```bash
# With netstat (legacy)
sudo netstat -tulnp   # tcp/udp, listening, numeric, show PIDs

# With ss (modern)
sudo ss -tulpn
```

To see established connections:
```bash
sudo ss -tunp
```

---

## 5) Firewalls (quick peek)
If you’re on Ubuntu Desktop/Server:
```bash
sudo ufw status verbose        # Uncomplicated Firewall
```
On RHEL/Amazon Linux:
```bash
sudo systemctl status firewalld
sudo firewall-cmd --list-all   # needs sudo + firewalld running
```

Cloud note: On cloud VMs (AWS EC2, Azure, GCP), **security groups** / **NSGs** can block ports **before** Linux firewall rules apply.

---

## 6) Capture evidence (script provided)
Run the helper script to save outputs into `artifacts/`:
```bash
chmod +x network_checks.sh
./network_checks.sh
ls -l artifacts/
```

Artifacts created:
- `01_ip_addr.txt`
- `02_ifconfig.txt` (if available)
- `03_ping_google.txt`
- `04_ping_8.8.8.8.txt`
- `05_curl_headers_example.txt`
- `06_curl_body_example.txt`
- `07_netstat_listen.txt` (if netstat available)
- `08_ss_listen.txt`
- `09_ss_established.txt`
- `10_firewall_status.txt`

---

## 7) Commit & push to GitHub
```bash
cd ~/DevOps-Training                         # or your repo root
mkdir -p week5
cp -r ~/projects/devops/week5/week5_networking ./week5/

git add week5/week5_networking
git commit -m "Week 5: networking basics (IP, ping, curl, ports, firewall)"
git push
```

If push asks for credentials, use **GitHub username + Personal Access Token** (not your password). If it asks to fetch first:
```bash
git pull --rebase origin main
git push
```

---

## 8) Checklist
- [ ] Found IP with `ip addr` (and `ifconfig` if installed)
- [ ] `ping google.com` and `ping 8.8.8.8` tested
- [ ] `curl -I` and `curl -L` used on a site
- [ ] Ports listed with `netstat -tulnp` and/or `ss -tulpn`
- [ ] Firewall status reviewed (`ufw` or `firewalld`)
- [ ] Outputs saved in `artifacts/` and pushed to repo
