#!/usr/bin/env bash
# network_checks.sh — collect Week 5 networking outputs into artifacts/
set -euo pipefail

mkdir -p artifacts

# 1) IP info
(ip addr show || true) > artifacts/01_ip_addr.txt 2>&1

# 2) ifconfig (legacy)
(ifconfig || true) > artifacts/02_ifconfig.txt 2>&1

# 3) ping DNS name and raw IP
(ping -c 4 google.com || true) > artifacts/03_ping_google.txt 2>&1
(ping -c 4 8.8.8.8 || true) > artifacts/04_ping_8.8.8.8.txt 2>&1

# 4) curl headers and body
(curl -I https://example.com || true) > artifacts/05_curl_headers_example.txt 2>&1
(curl -L https://example.com | head -n 40 || true) > artifacts/06_curl_body_example.txt 2>&1

# 5) ports with netstat and ss
(netstat -tulnp || true) > artifacts/07_netstat_listen.txt 2>&1
(ss -tulpn || true) > artifacts/08_ss_listen.txt 2>&1
(ss -tunp || true) > artifacts/09_ss_established.txt 2>&1

# 6) firewall status (try ufw then firewalld)
{
  (sudo ufw status verbose 2>/dev/null || true)
  (sudo systemctl status firewalld --no-pager 2>/dev/null || true)
  (sudo firewall-cmd --list-all 2>/dev/null || true)
} > artifacts/10_firewall_status.txt 2>&1

echo "Artifacts written to $(pwd)/artifacts"
